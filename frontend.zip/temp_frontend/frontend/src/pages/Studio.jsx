import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { api } from "../api/client.js";
import DocumentViewer from "../components/DocumentViewer.jsx";

export default function Studio() {
  const { jobId } = useParams();
  const [meta, setMeta] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [toggledOff, setToggledOff] = useState([]);

  useEffect(() => {
    api.getRedactionMap(jobId)
      .then((res) => setMeta(res.data))
      .catch((err) => setError(err.response?.data?.detail || "Job not found"))
      .finally(() => setLoading(false));
  }, [jobId]);

  const toggleRedaction = (index) => {
    setToggledOff((prev) =>
      prev.includes(index) ? prev.filter((i) => i !== index) : [...prev, index]
    );
  };

  if (loading) return <div className="page"><p>Loading job data...</p></div>;
  if (error) return (
    <div className="page">
      <Link to="/">← Back</Link>
      <p style={{ marginTop: 16, color: "var(--red)" }}>{error}</p>
    </div>
  );

  const piiFound = meta?.pii_found || [];

  return (
    <div className="page">
      <div className="flex items-center gap-12 mb-16">
        <Link to="/">← Back</Link>
        <h2 style={{ marginBottom: 0 }}>Manual Studio</h2>
        <span className="badge gray">{meta?.original_filename}</span>
        <span style={{ marginLeft: "auto" }}>
          <a href={`/outputs/${meta?.output_filename}`} download>
            <button className="primary">Download</button>
          </a>
        </span>
      </div>

      <div className="studio-layout">
        {/* Sidebar: redaction list */}
        <div>
          <h3>Redactions ({piiFound.length})</h3>
          <p style={{ fontSize: 12, marginBottom: 12 }}>
            Toggle items to un-redact or re-redact. Click an item to toggle.
          </p>
          <div className="redaction-list">
            {piiFound.length === 0 && (
              <div style={{ padding: 16, color: "var(--text-muted)", fontSize: 13 }}>
                No redactions found for this job.
              </div>
            )}
            {piiFound.map((m, i) => (
              <div
                key={i}
                className="redaction-item"
                style={{
                  cursor: "pointer",
                  opacity: toggledOff.includes(i) ? 0.5 : 1,
                  background: toggledOff.includes(i) ? "rgba(224,82,82,0.05)" : "transparent",
                }}
                onClick={() => toggleRedaction(i)}
                title={toggledOff.includes(i) ? "Click to re-redact" : "Click to un-redact"}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <span className={`badge ${toggledOff.includes(i) ? "red" : "purple"}`}>
                    {m.category}
                  </span>
                  <div className="original" style={{ marginTop: 4 }}>{m.original_text}</div>
                </div>
                <span style={{ fontSize: 18 }}>{toggledOff.includes(i) ? "○" : "●"}</span>
              </div>
            ))}
          </div>

          {toggledOff.length > 0 && (
            <p style={{ marginTop: 12, fontSize: 12, color: "var(--text-muted)" }}>
              {toggledOff.length} item(s) toggled off. Re-download to apply changes
              (re-processing endpoint coming soon).
            </p>
          )}
        </div>

        {/* Document viewer */}
        <div>
          <h3>Redacted Document Preview</h3>
          {meta?.output_filename?.endsWith(".pdf") ? (
            <DocumentViewer url={`/outputs/${meta.output_filename}`} />
          ) : (
            <div className="doc-viewer">
              <div style={{ textAlign: "center" }}>
                <p>DOCX preview not available in browser.</p>
                <a href={`/outputs/${meta?.output_filename}`} download>
                  <button className="primary" style={{ marginTop: 8 }}>
                    Download Redacted DOCX
                  </button>
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
