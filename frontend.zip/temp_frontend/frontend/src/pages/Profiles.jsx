import { useEffect, useState } from "react";
import { api, ALL_PII_CATEGORIES } from "../api/client.js";
import CategoryPicker from "../components/CategoryPicker.jsx";

const DEFAULT_PROFILE = {
  id: "",
  name: "",
  description: "",
  categories: [...ALL_PII_CATEGORIES],
  redaction_style: "black_box",
  custom_instructions: "",
};

export default function Profiles() {
  const [profiles, setProfiles] = useState([]);
  const [editing, setEditing] = useState(null);  // profile object being edited
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState({ ...DEFAULT_PROFILE });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  const loadProfiles = () => {
    api.listProfiles()
      .then((res) => setProfiles(res.data))
      .catch(() => setProfiles([]));
  };

  useEffect(() => { loadProfiles(); }, []);

  const startCreate = () => {
    setDraft({ ...DEFAULT_PROFILE });
    setCreating(true);
    setEditing(null);
  };

  const startEdit = (profile) => {
    setDraft({
      ...profile,
      categories: profile.categories === "ALL" ? [...ALL_PII_CATEGORIES] : [...profile.categories],
    });
    setEditing(profile.id);
    setCreating(false);
  };

  const cancelEdit = () => {
    setEditing(null);
    setCreating(false);
    setError(null);
  };

  const handleSave = async () => {
    if (!draft.name.trim()) {
      setError("Profile name is required.");
      return;
    }
    setSaving(true);
    setError(null);
    try {
      if (creating) {
        await api.createProfile(draft);
      } else {
        await api.updateProfile(editing, draft);
      }
      loadProfiles();
      cancelEdit();
    } catch (err) {
      setError(err.response?.data?.detail || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (profileId) => {
    if (!confirm("Delete this profile?")) return;
    try {
      await api.deleteProfile(profileId);
      loadProfiles();
    } catch {
      alert("Failed to delete profile.");
    }
  };

  const isEditorOpen = creating || editing !== null;

  return (
    <div className="page">
      <div className="flex items-center justify-between mb-16">
        <div>
          <h1 style={{ marginBottom: 4 }}>Redaction Profiles</h1>
          <p style={{ marginBottom: 0 }}>Save and reuse PII category configurations.</p>
        </div>
        {!isEditorOpen && (
          <button className="primary" onClick={startCreate}>+ New Profile</button>
        )}
      </div>

      {/* Profile Editor */}
      {isEditorOpen && (
        <div className="card">
          <h3>{creating ? "New Profile" : "Edit Profile"}</h3>

          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 13, display: "block", marginBottom: 4 }}>Profile Name *</label>
            <input
              value={draft.name}
              onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
              placeholder="e.g. Medical Records Profile"
            />
          </div>

          <div style={{ marginBottom: 12 }}>
            <label style={{ fontSize: 13, display: "block", marginBottom: 4 }}>Description</label>
            <input
              value={draft.description}
              onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))}
              placeholder="Optional description"
            />
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 13, display: "block", marginBottom: 8 }}>Redaction Style</label>
            <div className="style-picker">
              <label>
                <input
                  type="radio"
                  value="black_box"
                  checked={draft.redaction_style === "black_box"}
                  onChange={() => setDraft((d) => ({ ...d, redaction_style: "black_box" }))}
                />
                Black Box
              </label>
              <label>
                <input
                  type="radio"
                  value="label"
                  checked={draft.redaction_style === "label"}
                  onChange={() => setDraft((d) => ({ ...d, redaction_style: "label" }))}
                />
                [LABELS]
              </label>
            </div>
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 13, display: "block", marginBottom: 8 }}>PII Categories</label>
            <CategoryPicker
              selected={draft.categories}
              onChange={(cats) => setDraft((d) => ({ ...d, categories: cats }))}
            />
          </div>

          <div style={{ marginBottom: 16 }}>
            <label style={{ fontSize: 13, display: "block", marginBottom: 4 }}>Custom Instructions</label>
            <textarea
              value={draft.custom_instructions}
              onChange={(e) => setDraft((d) => ({ ...d, custom_instructions: e.target.value }))}
              placeholder="Any special instructions for this profile..."
              rows={2}
            />
          </div>

          {error && <p style={{ color: "var(--red)", marginBottom: 12, fontSize: 13 }}>{error}</p>}

          <div className="flex gap-8">
            <button className="primary" onClick={handleSave} disabled={saving}>
              {saving ? "Saving..." : "Save Profile"}
            </button>
            <button className="secondary" onClick={cancelEdit}>Cancel</button>
          </div>
        </div>
      )}

      {/* Profile List */}
      {profiles.length === 0 && !isEditorOpen && (
        <div className="card" style={{ textAlign: "center", color: "var(--text-muted)" }}>
          <p>No profiles yet. Create one to save your preferred redaction settings.</p>
        </div>
      )}

      {profiles.map((profile) => (
        <div key={profile.id} className="profile-card">
          <div style={{ flex: 1, minWidth: 0 }}>
            <h3>{profile.name}</h3>
            {profile.description && <p style={{ marginBottom: 4 }}>{profile.description}</p>}
            <div className="flex gap-8" style={{ flexWrap: "wrap", marginTop: 6 }}>
              <span className={`badge ${profile.redaction_style === "black_box" ? "gray" : "purple"}`}>
                {profile.redaction_style === "black_box" ? "Black Box" : "Labels"}
              </span>
              <span className="badge gray">
                {profile.categories === "ALL"
                  ? "All categories"
                  : `${Array.isArray(profile.categories) ? profile.categories.length : 0} categories`}
              </span>
            </div>
          </div>
          <div className="actions">
            <button className="secondary" onClick={() => startEdit(profile)}>Edit</button>
            <button
              className="secondary"
              style={{ color: "var(--red)", borderColor: "var(--red)" }}
              onClick={() => handleDelete(profile.id)}
            >
              Delete
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
