import { useState } from "react";
import { Link } from "react-router-dom";
import UploadZone from "../components/UploadZone.jsx";
import CategoryPicker from "../components/CategoryPicker.jsx";
import ProfileSelector from "../components/ProfileSelector.jsx";
import TemplateUpload from "../components/TemplateUpload.jsx";
import { api, ALL_PII_CATEGORIES } from "../api/client.js";

export default function Home() {
  const [files, setFiles] = useState([]);
  const [categories, setCategories] = useState([...ALL_PII_CATEGORIES]);
  const [style, setStyle] = useState("black_box");
  const [instructions, setInstructions] = useState("");
  const [templateFile, setTemplateFile] = useState(null);
  const [result, setResult] = useState(null);
  const [batchResult, setBatchResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const loadProfile = (profile) => {
    if (profile.categories === "ALL") {
      setCategories([...ALL_PII_CATEGORIES]);
    } else {
      setCategories(profile.categories);
    }
    setStyle(profile.redaction_style || "black_box");
    if (profile.custom_instructions) setInstructions(profile.custom_instructions);
  };

  const handleRedact = async () => {
    if (!files.length) return;
    setLoading(true);
    setError(null);
    setResult(null);
    setBatchResult(null);

    const config = {
      categories,
      redaction_style: style,
      custom_instructions: instructions || undefined,
    };

    try {
      if (files.length === 1) {
        const res = await api.redactSingle(files[0], config);
        setResult(res.data);
      } else {
        const res = await api.submitBatch(files, config);
        pollBatch(res.data.batch_id);
      }
    } catch (err) {
      setError(err.response?.data?.detail || err.message || "An error occurred");
    } finally {
      if (files.length === 1) setLoading(false);
    }
  };

  const pollBatch = (batchId) => {
    const interval = setInterval(async () => {
      try {
        const res = await api.getBatchStatus(batchId);
        setBatchResult(res.data);
        if (["done", "partial", "failed"].includes(res.data.status)) {
          clearInterval(interval);
          setLoading(false);
        }
      } catch {
        clearInterval(interval);
        setLoading(false);
      }
    }, 3000);
  };

  return (
    <div className="page">
      <h1>Redacto</h1>
      <p>Upload documents. Select what to redact. Download clean files.</p>

      {/* Upload Zone */}
      <div className="card">
        <h3>1. Upload Documents</h3>
        <UploadZone files={files} onDrop={setFiles} multiple />
      </div>

      {/* Redaction Style */}
      <div className="card">
        <h3>2. Redaction Style</h3>
        <div className="style-picker">
          <label>
            <input
              type="radio"
              value="black_box"
              checked={style === "black_box"}
              onChange={() => setStyle("black_box")}
            />
            Black Box (classic redaction)
          </label>
          <label>
            <input
              type="radio"
              value="label"
              checked={style === "label"}
              onChange={() => setStyle("label")}
            />
            [NAME] Labels (readable placeholders)
          </label>
        </div>
      </div>

      {/* Profile Loader */}
      <div className="card">
        <div className="flex items-center justify-between mb-16">
          <h3 style={{ marginBottom: 0 }}>3. PII Categories</h3>
          <div className="flex items-center gap-8">
            <span style={{ fontSize: 13, color: "var(--text-muted)" }}>Load profile:</span>
            <ProfileSelector onSelect={loadProfile} />
          </div>
        </div>
        <CategoryPicker selected={categories} onChange={setCategories} />
      </div>

      {/* Custom Instructions */}
      <div className="card">
        <h3>4. Custom Instructions (optional)</h3>
        <textarea
          placeholder="Describe any special redaction needs, e.g. 'Also redact all project code names' or 'Do not redact company name ACME'"
          value={instructions}
          onChange={(e) => setInstructions(e.target.value)}
          rows={3}
        />
      </div>

      {/* Template Upload */}
      <div className="card">
        <h3>5. Output Template (optional)</h3>
        <TemplateUpload value={templateFile} onChange={setTemplateFile} />
      </div>

      {/* Submit */}
      <button
        className="primary"
        onClick={handleRedact}
        disabled={loading || !files.length || !categories.length}
        style={{ width: "100%", padding: "14px", fontSize: 16, marginBottom: 20 }}
      >
        {loading ? (
          <><span className="spinner" />Redacting...</>
        ) : (
          `Redact ${files.length} Document${files.length !== 1 ? "s" : ""}`
        )}
      </button>

      {/* Error */}
      {error && (
        <div style={{ padding: 16, background: "rgba(224,82,82,0.1)", border: "1px solid var(--red)", borderRadius: 8, marginBottom: 16 }}>
          <p style={{ color: "var(--red)", margin: 0 }}>Error: {error}</p>
        </div>
      )}

      {/* Single file result */}
      {result && (
        <div className="results">
          <p>
            <strong style={{ color: "var(--green)" }}>Done!</strong>{" "}
            {result.total_redactions} redactions applied to <em>{result.original_filename}</em>
          </p>
          <a href={result.download_url} download>
            <button className="primary">Download Redacted Document</button>
          </a>
          <Link to={`/studio/${result.job_id}`} style={{ marginLeft: 12 }}>
            Open in Manual Studio →
          </Link>

          {result.pii_found && result.pii_found.length > 0 && (
            <details style={{ marginTop: 16 }}>
              <summary style={{ cursor: "pointer", fontSize: 13, color: "var(--text-muted)" }}>
                View {result.pii_found.length} detected items
              </summary>
              <div className="redaction-list" style={{ marginTop: 8 }}>
                {result.pii_found.map((m, i) => (
                  <div key={i} className="redaction-item">
                    <span className="badge purple">{m.category}</span>
                    <span className="original">{m.original_text}</span>
                    <span style={{ color: "var(--text-muted)", fontSize: 12 }}>{m.replacement}</span>
                  </div>
                ))}
              </div>
            </details>
          )}
        </div>
      )}

      {/* Batch result */}
      {batchResult && (
        <div className="results">
          <p>
            Batch{" "}
            <span className={`badge ${batchResult.status === "done" ? "green" : batchResult.status === "failed" ? "red" : "purple"}`}>
              {batchResult.status}
            </span>
            {" "}{batchResult.completed}/{batchResult.total_files} complete
          </p>
          {batchResult.results?.map((r, i) => (
            <div key={i} className="batch-item" style={{ borderTop: "1px solid var(--border)", paddingTop: 8, marginTop: 8 }}>
              <span style={{ flex: 1, fontSize: 13 }}>{r.original_filename}</span>
              {r.download_url && (
                <a href={r.download_url} download>
                  <button className="secondary" style={{ padding: "4px 10px", fontSize: 12 }}>
                    Download
                  </button>
                </a>
              )}
              {r.status === "failed" && (
                <span className="badge red">failed</span>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
