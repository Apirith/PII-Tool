import { useState } from "react";
import UploadZone from "../components/UploadZone.jsx";
import CategoryPicker from "../components/CategoryPicker.jsx";
import ProfileSelector from "../components/ProfileSelector.jsx";
import BatchProgress from "../components/BatchProgress.jsx";
import { api, ALL_PII_CATEGORIES } from "../api/client.js";

export default function Batch() {
  const [files, setFiles] = useState([]);
  const [categories, setCategories] = useState([...ALL_PII_CATEGORIES]);
  const [style, setStyle] = useState("black_box");
  const [instructions, setInstructions] = useState("");
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const loadProfile = (profile) => {
    if (profile.categories === "ALL") setCategories([...ALL_PII_CATEGORIES]);
    else setCategories(profile.categories);
    setStyle(profile.redaction_style || "black_box");
  };

  const handleSubmit = async () => {
    if (!files.length) return;
    setLoading(true);
    setError(null);
    setJob(null);

    try {
      const config = { categories, redaction_style: style, custom_instructions: instructions || undefined };
      const res = await api.submitBatch(files, config);
      const batchId = res.data.batch_id;
      setJob(res.data);

      // Start polling
      const interval = setInterval(async () => {
        const statusRes = await api.getBatchStatus(batchId);
        setJob(statusRes.data);
        if (["done", "partial", "failed"].includes(statusRes.data.status)) {
          clearInterval(interval);
          setLoading(false);
        }
      }, 3000);
    } catch (err) {
      setError(err.response?.data?.detail || err.message || "Batch submission failed");
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <h1>Batch Processing</h1>
      <p>Submit 100+ documents for automated background redaction.</p>

      <div className="card">
        <h3>1. Upload Documents</h3>
        <UploadZone files={files} onDrop={setFiles} multiple />
        {files.length > 0 && (
          <p style={{ marginTop: 8, fontSize: 12, color: "var(--accent)", marginBottom: 0 }}>
            {files.length} file(s) ready
          </p>
        )}
      </div>

      <div className="card">
        <h3>2. Redaction Style</h3>
        <div className="style-picker">
          <label>
            <input type="radio" value="black_box" checked={style === "black_box"} onChange={() => setStyle("black_box")} />
            Black Box
          </label>
          <label>
            <input type="radio" value="label" checked={style === "label"} onChange={() => setStyle("label")} />
            [LABELS]
          </label>
        </div>
      </div>

      <div className="card">
        <div className="flex items-center justify-between mb-16">
          <h3 style={{ marginBottom: 0 }}>3. PII Categories</h3>
          <div className="flex items-center gap-8">
            <span style={{ fontSize: 13, color: "var(--text-muted)" }}>Load profile:</span>
            <ProfileSelector onSelect={loadProfile} />
          </div>
        </div>
        <CategoryPicker selected={categories} onChange={setCategories} />
      </div>

      <div className="card">
        <h3>4. Custom Instructions (optional)</h3>
        <textarea
          placeholder="Any special instructions for this batch..."
          value={instructions}
          onChange={(e) => setInstructions(e.target.value)}
          rows={2}
        />
      </div>

      <button
        className="primary"
        onClick={handleSubmit}
        disabled={loading || !files.length || !categories.length}
        style={{ width: "100%", padding: 14, fontSize: 16, marginBottom: 20 }}
      >
        {loading ? (
          <><span className="spinner" />Processing Batch...</>
        ) : (
          `Submit ${files.length} File${files.length !== 1 ? "s" : ""} for Batch Redaction`
        )}
      </button>

      {error && (
        <div style={{ padding: 16, background: "rgba(224,82,82,0.1)", border: "1px solid var(--red)", borderRadius: 8, marginBottom: 16 }}>
          <p style={{ color: "var(--red)", margin: 0 }}>Error: {error}</p>
        </div>
      )}

      {job && (
        <div className="card">
          <h3>Batch {job.batch_id}</h3>
          <BatchProgress job={job} />
        </div>
      )}
    </div>
  );
}
