import axios from "axios";

const API_BASE = "/api";

export const api = {
  // Single document redaction
  redactSingle: (file, config) => {
    const form = new FormData();
    form.append("file", file);
    form.append("config", JSON.stringify(config));
    return axios.post(`${API_BASE}/redact/single`, form);
  },

  // Get redaction map for a job (Manual Studio)
  getRedactionMap: (jobId) =>
    axios.get(`${API_BASE}/redact/map/${jobId}`),

  // Batch processing
  submitBatch: (files, config) => {
    const form = new FormData();
    files.forEach((f) => form.append("files", f));
    form.append("config", JSON.stringify(config));
    return axios.post(`${API_BASE}/batch/submit`, form);
  },

  getBatchStatus: (batchId) =>
    axios.get(`${API_BASE}/batch/status/${batchId}`),

  // Profiles CRUD
  listProfiles: () => axios.get(`${API_BASE}/profiles/`),

  createProfile: (profile) =>
    axios.post(`${API_BASE}/profiles/`, profile),

  updateProfile: (profileId, profile) =>
    axios.put(`${API_BASE}/profiles/${profileId}`, profile),

  deleteProfile: (profileId) =>
    axios.delete(`${API_BASE}/profiles/${profileId}`),

  // Jobs
  getJob: (jobId) => axios.get(`${API_BASE}/jobs/${jobId}`),

  // Health
  health: () => axios.get(`${API_BASE}/health`),
};

export const ALL_PII_CATEGORIES = [
  "person_name", "email_address", "phone_number", "location",
  "date_of_birth", "date", "us_social_security_number", "drivers_license",
  "passport_number", "credit_card_number", "credit_card_cvv",
  "credit_card_expiration", "banking_information", "account_number",
  "healthcare_number", "medical_condition", "medical_process", "injury",
  "blood_type", "drug", "occupation", "organization", "ip_address",
  "url", "username", "password", "vehicle_id", "gender_sexuality",
  "nationality", "religion", "political_affiliation", "money_amount",
  "person_age", "number_sequence", "language", "event",
  "image_faces", "image_all",
];
