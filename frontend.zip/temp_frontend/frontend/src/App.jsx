import { BrowserRouter, Routes, Route, NavLink } from "react-router-dom";
import Home from "./pages/Home.jsx";
import Studio from "./pages/Studio.jsx";
import Batch from "./pages/Batch.jsx";
import Profiles from "./pages/Profiles.jsx";

export default function App() {
  return (
    <BrowserRouter>
      <nav>
        <span className="logo">Redacto</span>
        <NavLink to="/" end className={({ isActive }) => isActive ? "active" : ""}>
          Redact
        </NavLink>
        <NavLink to="/batch" className={({ isActive }) => isActive ? "active" : ""}>
          Batch
        </NavLink>
        <NavLink to="/profiles" className={({ isActive }) => isActive ? "active" : ""}>
          Profiles
        </NavLink>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/studio/:jobId" element={<Studio />} />
        <Route path="/batch" element={<Batch />} />
        <Route path="/profiles" element={<Profiles />} />
      </Routes>
    </BrowserRouter>
  );
}
