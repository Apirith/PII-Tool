import { useState } from "react";

const PII_CATEGORIES = [
  { id: "person_name", label: "Person Names", group: "Identity" },
  { id: "email_address", label: "Email Addresses", group: "Contact" },
  { id: "phone_number", label: "Phone Numbers", group: "Contact" },
  { id: "location", label: "Addresses & Locations", group: "Contact" },
  { id: "date_of_birth", label: "Date of Birth", group: "Identity" },
  { id: "date", label: "All Dates", group: "Identity" },
  { id: "person_age", label: "Age References", group: "Identity" },
  { id: "us_social_security_number", label: "SSN", group: "Government ID" },
  { id: "drivers_license", label: "Driver's License", group: "Government ID" },
  { id: "passport_number", label: "Passport Number", group: "Government ID" },
  { id: "credit_card_number", label: "Credit Card Numbers", group: "Financial" },
  { id: "credit_card_cvv", label: "CVV Codes", group: "Financial" },
  { id: "credit_card_expiration", label: "Card Expiry Dates", group: "Financial" },
  { id: "banking_information", label: "Bank Account Info", group: "Financial" },
  { id: "account_number", label: "Account/Policy Numbers", group: "Financial" },
  { id: "money_amount", label: "Dollar/Currency Amounts", group: "Financial" },
  { id: "occupation", label: "Job Titles", group: "Professional" },
  { id: "organization", label: "Companies & Schools", group: "Professional" },
  { id: "healthcare_number", label: "Health Insurance IDs", group: "Medical" },
  { id: "medical_condition", label: "Medical Conditions", group: "Medical" },
  { id: "medical_process", label: "Medical Procedures", group: "Medical" },
  { id: "injury", label: "Injury References", group: "Medical" },
  { id: "blood_type", label: "Blood Type", group: "Medical" },
  { id: "drug", label: "Medications/Supplements", group: "Medical" },
  { id: "vehicle_id", label: "Vehicle IDs / Plates", group: "IDs" },
  { id: "number_sequence", label: "ID Numbers (other)", group: "IDs" },
  { id: "ip_address", label: "IP Addresses", group: "Digital" },
  { id: "url", label: "URLs", group: "Digital" },
  { id: "username", label: "Usernames/Handles", group: "Digital" },
  { id: "password", label: "Passwords/PINs", group: "Digital" },
  { id: "gender_sexuality", label: "Gender/Sexuality Terms", group: "Sensitive" },
  { id: "nationality", label: "Nationality/Ethnicity/Race", group: "Sensitive" },
  { id: "religion", label: "Religion", group: "Sensitive" },
  { id: "political_affiliation", label: "Political Affiliation", group: "Sensitive" },
  { id: "language", label: "Languages", group: "Other" },
  { id: "event", label: "Named Events", group: "Other" },
  { id: "image_all", label: "All Embedded Images", group: "Media" },
  { id: "image_faces", label: "Faces in Images", group: "Media" },
];

const GROUPS = [...new Set(PII_CATEGORIES.map((c) => c.group))];

export default function CategoryPicker({ selected, onChange }) {
  const [expanded, setExpanded] = useState({});

  const toggleGroup = (group) => {
    const groupIds = PII_CATEGORIES.filter((c) => c.group === group).map((c) => c.id);
    const allSelected = groupIds.every((id) => selected.includes(id));
    if (allSelected) {
      onChange(selected.filter((id) => !groupIds.includes(id)));
    } else {
      onChange([...new Set([...selected, ...groupIds])]);
    }
  };

  const toggle = (id) => {
    if (selected.includes(id)) {
      onChange(selected.filter((i) => i !== id));
    } else {
      onChange([...selected, id]);
    }
  };

  return (
    <div className="category-picker">
      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <button
          className="secondary"
          onClick={() => onChange(PII_CATEGORIES.map((c) => c.id))}
        >
          Select All
        </button>
        <button className="secondary" onClick={() => onChange([])}>
          Clear All
        </button>
        <span style={{ marginLeft: "auto", fontSize: 13, color: "var(--text-muted)", alignSelf: "center" }}>
          {selected.length} / {PII_CATEGORIES.length} selected
        </span>
      </div>

      {GROUPS.map((group) => {
        const cats = PII_CATEGORIES.filter((c) => c.group === group);
        const allChecked = cats.every((c) => selected.includes(c.id));
        const someChecked = cats.some((c) => selected.includes(c.id));
        const isExpanded = expanded[group];

        return (
          <div key={group} className="category-group">
            <div
              className="group-header"
              onClick={() => setExpanded((e) => ({ ...e, [group]: !e[group] }))}
            >
              <input
                type="checkbox"
                checked={allChecked}
                ref={(el) => { if (el) el.indeterminate = someChecked && !allChecked; }}
                onChange={() => toggleGroup(group)}
                onClick={(e) => e.stopPropagation()}
              />
              <strong>{group}</strong>
              <span style={{ fontSize: 12, color: "var(--text-muted)" }}>
                {cats.filter((c) => selected.includes(c.id)).length}/{cats.length}
              </span>
              <button>{isExpanded ? "▲" : "▼"}</button>
            </div>

            {isExpanded && (
              <div className="group-items">
                {cats.map((cat) => (
                  <label key={cat.id}>
                    <input
                      type="checkbox"
                      checked={selected.includes(cat.id)}
                      onChange={() => toggle(cat.id)}
                    />
                    {cat.label}
                  </label>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
