/**
 * RedactionOverlay
 * Renders clickable redaction boxes over a rendered PDF page.
 * Receives redactions as {original_text, category, replacement} objects.
 * Allows toggling individual redactions on/off.
 */
export default function RedactionOverlay({ redactions, toggledOff, onToggle }) {
  if (!redactions || redactions.length === 0) return null;

  return (
    <div style={{ position: "relative" }}>
      {redactions.map((r, i) => {
        const isOff = toggledOff.includes(i);
        return (
          <div
            key={i}
            onClick={() => onToggle(i)}
            title={isOff ? `Show: "${r.original_text}"` : `Click to un-redact: ${r.category}`}
            style={{
              display: "inline-block",
              background: isOff ? "transparent" : "#000",
              color: isOff ? "var(--text)" : "transparent",
              padding: "0 4px",
              borderRadius: 2,
              cursor: "pointer",
              border: isOff ? "1px dashed var(--accent)" : "none",
              fontSize: 14,
              margin: "0 2px",
              userSelect: "none",
            }}
          >
            {isOff ? r.original_text : r.replacement || "████████"}
          </div>
        );
      })}
    </div>
  );
}
