export default function TemplateUpload({ value, onChange }) {
  return (
    <div>
      <label style={{ fontSize: 13, color: "var(--text-muted)", display: "block", marginBottom: 6 }}>
        Optional: Upload a template document to match output style
      </label>
      <input
        type="file"
        accept=".pdf,.docx"
        onChange={(e) => onChange(e.target.files[0] || null)}
        style={{ width: "auto" }}
      />
      {value && (
        <p style={{ marginTop: 6, fontSize: 12, color: "var(--accent)" }}>
          Template: {value.name}
        </p>
      )}
    </div>
  );
}
