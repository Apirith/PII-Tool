export default function BatchProgress({ job }) {
  if (!job) return null;

  const { total_files, completed, failed, status, results } = job;
  const percent = total_files > 0 ? Math.round(((completed + failed) / total_files) * 100) : 0;

  const statusColor = {
    processing: "purple",
    done: "green",
    partial: "purple",
    failed: "red",
  }[status] || "gray";

  return (
    <div>
      <div className="flex items-center gap-12 mb-16">
        <span className={`badge ${statusColor}`}>{status}</span>
        <span style={{ fontSize: 13 }}>
          {completed} completed · {failed} failed · {total_files} total
        </span>
        <span style={{ marginLeft: "auto", fontSize: 13, color: "var(--text-muted)" }}>
          {percent}%
        </span>
      </div>

      {/* Progress bar */}
      <div style={{
        height: 6, background: "var(--surface2)", borderRadius: 99, marginBottom: 16, overflow: "hidden"
      }}>
        <div style={{
          height: "100%",
          width: `${percent}%`,
          background: status === "failed" ? "var(--red)" : "var(--accent)",
          transition: "width 0.4s ease",
          borderRadius: 99
        }} />
      </div>

      {/* File list */}
      <div className="redaction-list">
        {results && results.map((r, i) => (
          <div key={i} className="batch-item">
            <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {r.original_filename}
            </span>
            {r.status === "completed" ? (
              <>
                <span style={{ color: "var(--text-muted)", fontSize: 12, marginRight: 12 }}>
                  {r.total_redactions} redactions
                </span>
                <a href={r.download_url} download>
                  <button className="secondary" style={{ padding: "4px 10px", fontSize: 12 }}>
                    Download
                  </button>
                </a>
              </>
            ) : (
              <span className="badge red">failed</span>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
