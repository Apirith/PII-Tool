import { useDropzone } from "react-dropzone";

export default function UploadZone({ files, onDrop, multiple = true }) {
  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    accept: {
      "application/pdf": [".pdf"],
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document": [".docx"],
    },
    onDrop,
    multiple,
  });

  return (
    <div {...getRootProps()} className={`dropzone${isDragActive ? " active" : ""}`}>
      <input {...getInputProps()} />
      {files.length > 0 ? (
        <ul>
          {files.map((f) => (
            <li key={f.name}>{f.name}</li>
          ))}
        </ul>
      ) : (
        <p>Drop PDFs or DOCX files here, or click to browse</p>
      )}
    </div>
  );
}
