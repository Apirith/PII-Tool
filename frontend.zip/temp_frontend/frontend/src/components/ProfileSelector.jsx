import { useEffect, useState } from "react";
import { api } from "../api/client.js";

export default function ProfileSelector({ onSelect }) {
  const [profiles, setProfiles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.listProfiles()
      .then((res) => setProfiles(res.data))
      .catch(() => setProfiles([]))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p style={{ fontSize: 13 }}>Loading profiles...</p>;
  if (!profiles.length) return <p style={{ fontSize: 13 }}>No saved profiles yet.</p>;

  return (
    <div>
      <select
        onChange={(e) => {
          const p = profiles.find((x) => x.id === e.target.value);
          if (p) onSelect(p);
        }}
        defaultValue=""
        style={{ width: "auto", minWidth: 200 }}
      >
        <option value="" disabled>Load a saved profile...</option>
        {profiles.map((p) => (
          <option key={p.id} value={p.id}>{p.name}</option>
        ))}
      </select>
    </div>
  );
}
