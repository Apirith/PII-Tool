import { useState } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";

// Required: set PDF.js worker source
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

export default function DocumentViewer({ url }) {
  const [numPages, setNumPages] = useState(null);
  const [pageNumber, setPageNumber] = useState(1);

  if (!url) {
    return (
      <div className="doc-viewer">
        <p>No document loaded</p>
      </div>
    );
  }

  return (
    <div>
      <Document
        file={url}
        onLoadSuccess={({ numPages }) => setNumPages(numPages)}
        loading={<div className="doc-viewer"><p>Loading PDF...</p></div>}
        error={<div className="doc-viewer"><p>Failed to load PDF. <a href={url} target="_blank" rel="noreferrer">Download instead</a></p></div>}
      >
        <Page pageNumber={pageNumber} width={600} />
      </Document>

      {numPages && (
        <div className="flex items-center gap-12 mt-16" style={{ justifyContent: "center" }}>
          <button
            className="secondary"
            onClick={() => setPageNumber((p) => Math.max(1, p - 1))}
            disabled={pageNumber <= 1}
          >
            ← Prev
          </button>
          <span style={{ fontSize: 13 }}>Page {pageNumber} of {numPages}</span>
          <button
            className="secondary"
            onClick={() => setPageNumber((p) => Math.min(numPages, p + 1))}
            disabled={pageNumber >= numPages}
          >
            Next →
          </button>
        </div>
      )}
    </div>
  );
}
