from pydantic import BaseModel
from typing import List, Optional, Dict, Any

# Full list of detectable PII categories
ALL_PII_CATEGORIES = [
    "person_name", "email_address", "phone_number", "location",
    "date_of_birth", "date", "us_social_security_number", "drivers_license",
    "passport_number", "credit_card_number", "credit_card_cvv",
    "credit_card_expiration", "banking_information", "account_number",
    "healthcare_number", "medical_condition", "medical_process", "injury",
    "blood_type", "drug", "occupation", "organization", "ip_address",
    "url", "username", "password", "vehicle_id", "gender_sexuality",
    "nationality", "religion", "political_affiliation", "money_amount",
    "person_age", "number_sequence", "language", "event",
    "image_faces", "image_all"
]

class RedactionConfig(BaseModel):
    categories: List[str] = ALL_PII_CATEGORIES  # which PII types to redact
    redaction_style: str = "black_box"           # "black_box" or "label" e.g. [NAME]
    custom_instructions: Optional[str] = None    # freetext user instructions
    profile_id: Optional[str] = None            # saved profile to apply
    template_file_id: Optional[str] = None      # style template reference

class PIIMatch(BaseModel):
    category: str
    original_text: str
    replacement: str                             # what to show (e.g. "[NAME]" or "████")
    page: int
    position: Optional[Dict[str, float]] = None # x0,y0,x1,y1 bounding box

class RedactionResult(BaseModel):
    job_id: str
    original_filename: str
    output_filename: str
    download_url: str
    pii_found: List[PIIMatch]
    total_redactions: int
    status: str

class RedactionProfile(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    categories: List[str]
    redaction_style: str = "black_box"
    custom_instructions: Optional[str] = None

class BatchJob(BaseModel):
    batch_id: str
    total_files: int
    completed: int
    failed: int
    status: str                                  # "queued", "processing", "done", "partial"
    results: List[RedactionResult] = []
