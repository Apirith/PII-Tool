from fastapi import APIRouter, UploadFile, File, HTTPException
import uuid, os, aiofiles
from dotenv import load_dotenv

load_dotenv()
router = APIRouter()

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "./storage/uploads")
MAX_FILE_SIZE_MB = int(os.getenv("MAX_FILE_SIZE_MB", "50"))
os.makedirs(UPLOAD_DIR, exist_ok=True)


@router.post("/")
async def upload_file(file: UploadFile = File(...)):
    """
    Upload a single file for later redaction.
    Returns a file_id that can be referenced in redaction requests.
    """
    filename = file.filename or "document"
    ext = filename.rsplit(".", 1)[-1].lower()
    if ext not in ("pdf", "docx"):
        raise HTTPException(400, "Only PDF and DOCX files are supported.")

    # Check file size
    content = await file.read()
    size_mb = len(content) / (1024 * 1024)
    if size_mb > MAX_FILE_SIZE_MB:
        raise HTTPException(413, f"File exceeds maximum size of {MAX_FILE_SIZE_MB}MB.")

    file_id = str(uuid.uuid4())[:8]
    file_path = os.path.join(UPLOAD_DIR, f"{file_id}.{ext}")

    async with aiofiles.open(file_path, "wb") as f:
        await f.write(content)

    return {
        "file_id": file_id,
        "filename": filename,
        "size_mb": round(size_mb, 2),
        "ext": ext
    }
