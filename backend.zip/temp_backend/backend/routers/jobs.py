from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
import os, json

router = APIRouter()

OUTPUT_DIR = os.getenv("OUTPUT_DIR", "./storage/outputs")


@router.get("/{job_id}")
def get_job(job_id: str):
    """Get job metadata for a completed redaction job."""
    meta_path = os.path.join(OUTPUT_DIR, f"{job_id}_meta.json")
    if not os.path.exists(meta_path):
        raise HTTPException(404, "Job not found")
    with open(meta_path) as f:
        return json.load(f)


@router.get("/{job_id}/download")
def download_job(job_id: str):
    """Download the redacted file for a completed job."""
    meta_path = os.path.join(OUTPUT_DIR, f"{job_id}_meta.json")
    if not os.path.exists(meta_path):
        raise HTTPException(404, "Job not found")
    with open(meta_path) as f:
        meta = json.load(f)

    output_path = os.path.join(OUTPUT_DIR, meta["output_filename"])
    if not os.path.exists(output_path):
        raise HTTPException(404, "Output file not found")

    return FileResponse(
        output_path,
        filename=meta["output_filename"],
        media_type="application/octet-stream"
    )
