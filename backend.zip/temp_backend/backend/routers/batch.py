from fastapi import APIRouter, UploadFile, File, Form, BackgroundTasks
from typing import List
import uuid, json, os
from models.schemas import RedactionConfig, BatchJob
from services.batch_processor import process_batch_files

router = APIRouter()
batch_status_store: dict = {}   # In production: use Redis


@router.post("/submit")
async def submit_batch(
    background_tasks: BackgroundTasks,
    files: List[UploadFile] = File(...),
    config: str = Form(...)
):
    """
    Submit multiple files for automated background redaction.
    Returns a batch_id for polling.
    """
    cfg = RedactionConfig(**json.loads(config))
    batch_id = str(uuid.uuid4())[:8]

    # Save files temporarily
    upload_dir = os.getenv("UPLOAD_DIR", "./storage/uploads")
    saved_paths = []
    for f in files:
        ext = (f.filename or "doc").rsplit(".", 1)[-1].lower()
        path = os.path.join(upload_dir, f"{batch_id}_{f.filename}")
        with open(path, "wb") as fp:
            fp.write(f.file.read())
        saved_paths.append((path, f.filename or "document"))

    # Initialize job record
    batch_status_store[batch_id] = {
        "batch_id": batch_id,
        "total_files": len(saved_paths),
        "completed": 0,
        "failed": 0,
        "status": "processing",
        "results": []
    }

    # Run in background (use Celery for production)
    background_tasks.add_task(
        process_batch_files,
        batch_id, saved_paths, cfg, batch_status_store
    )

    return {"batch_id": batch_id, "total_files": len(saved_paths), "status": "processing"}


@router.get("/status/{batch_id}")
def get_batch_status(batch_id: str):
    """Poll for batch completion status."""
    job = batch_status_store.get(batch_id)
    if not job:
        return {"error": "Batch not found"}
    return job
