from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
import uuid, os, json, re, aiofiles
from models.schemas import RedactionConfig, RedactionResult, PIIMatch
from services.claude_detector import detect_pii
from services.pdf_redactor import redact_pdf
from services.docx_redactor import redact_docx
from dotenv import load_dotenv

load_dotenv()
router = APIRouter()

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "./storage/uploads")
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "./storage/outputs")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)


@router.post("/single", response_model=RedactionResult)
async def redact_single(
    file: UploadFile = File(...),
    config: str = Form(...)   # JSON string of RedactionConfig
):
    """Redact a single PDF or DOCX file."""
    cfg = RedactionConfig(**json.loads(config))

    # Validate file type
    filename = file.filename or "document"
    ext = filename.rsplit(".", 1)[-1].lower()
    if ext not in ("pdf", "docx"):
        raise HTTPException(400, "Only PDF and DOCX files are supported.")

    job_id = str(uuid.uuid4())[:8]
    input_path = os.path.join(UPLOAD_DIR, f"{job_id}_input.{ext}")
    base_name = filename.rsplit(".", 1)[0]
    safe_name = re.sub(r'[^\w\s\-]', '', base_name).strip()
    output_filename = f"{safe_name}_redacted.{ext}"
    output_path = os.path.join(OUTPUT_DIR, output_filename)

    # Save uploaded file
    async with aiofiles.open(input_path, "wb") as f:
        await f.write(await file.read())

    # Step 1: Extract text
    text = extract_text(input_path, ext)

    # Step 2: Detect PII with Claude
    raw_matches = detect_pii(
        text=text,
        categories=cfg.categories,
        custom_instructions=cfg.custom_instructions or ""
    )

    # Step 3: Build PIIMatch objects
    pii_matches = [
        PIIMatch(
            category=m.get("category", "unknown"),
            original_text=m.get("original_text", ""),
            replacement=build_replacement(m.get("category", ""), m.get("original_text", ""), cfg.redaction_style),
            page=0
        )
        for m in raw_matches if m.get("original_text")
    ]

    # Step 4: Apply redactions
    redact_images = "image_all" in cfg.categories
    redact_faces = "image_faces" in cfg.categories

    raw_dicts = [{"category": m.category, "original_text": m.original_text} for m in pii_matches]

    if ext == "pdf":
        count = redact_pdf(input_path, output_path, raw_dicts, cfg.redaction_style, redact_images, redact_faces)
    else:
        count = redact_docx(input_path, output_path, raw_dicts, cfg.redaction_style, redact_images)

    # Save job metadata for Manual Studio
    meta_path = os.path.join(OUTPUT_DIR, f"{job_id}_meta.json")
    with open(meta_path, "w") as mf:
        json.dump({
            "job_id": job_id,
            "original_filename": filename,
            "output_filename": output_filename,
            "pii_found": [m.model_dump() for m in pii_matches],
            "total_redactions": count
        }, mf, indent=2)

    # Cleanup input
    os.remove(input_path)

    return RedactionResult(
        job_id=job_id,
        original_filename=filename,
        output_filename=output_filename,
        download_url=f"/outputs/{output_filename}",
        pii_found=pii_matches,
        total_redactions=count,
        status="completed"
    )


@router.get("/map/{job_id}")
def get_redaction_map(job_id: str):
    """Return list of redaction bounding boxes for overlay rendering (Manual Studio)."""
    meta_path = os.path.join(OUTPUT_DIR, f"{job_id}_meta.json")
    if not os.path.exists(meta_path):
        raise HTTPException(404, "Job metadata not found")
    with open(meta_path) as f:
        return json.load(f)


@router.post("/adjust/{job_id}")
def adjust_redactions(job_id: str, adjustments: list):
    """Re-apply redactions with user adjustments and regenerate output file."""
    # Load original (pre-redaction) file, re-run with new PII list
    # This is a placeholder for the Manual Studio adjustment feature
    raise HTTPException(501, "Manual adjustment re-processing not yet implemented")


def extract_text(path: str, ext: str) -> str:
    """Extract plain text from PDF or DOCX."""
    if ext == "pdf":
        import pymupdf
        doc = pymupdf.open(path)
        return "\n".join(page.get_text() for page in doc)
    elif ext == "docx":
        from docx import Document
        doc = Document(path)
        return "\n".join(p.text for p in doc.paragraphs)
    return ""


def build_replacement(category: str, original: str, style: str) -> str:
    label_map = {
        "person_name": "[NAME]", "email_address": "[EMAIL]",
        "phone_number": "[PHONE]", "location": "[ADDRESS]",
        "date_of_birth": "[DOB]", "organization": "[ORGANIZATION]",
        "occupation": "[JOB TITLE]", "medical_condition": "[MEDICAL]",
        "us_social_security_number": "[SSN]", "credit_card_number": "[CARD #]",
    }
    if style == "label":
        return label_map.get(category, f"[{category.upper().replace('_', ' ')}]")
    return "█" * max(len(original), 6)
