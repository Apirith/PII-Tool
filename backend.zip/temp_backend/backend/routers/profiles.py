from fastapi import APIRouter, HTTPException
from models.schemas import RedactionProfile
import json, uuid, os

router = APIRouter()
PROFILES_FILE = "./storage/profiles.json"


def load_profiles():
    if not os.path.exists(PROFILES_FILE):
        return {}
    with open(PROFILES_FILE) as f:
        return json.load(f)


def save_profiles(profiles):
    os.makedirs(os.path.dirname(PROFILES_FILE), exist_ok=True)
    with open(PROFILES_FILE, "w") as f:
        json.dump(profiles, f, indent=2)


@router.get("/")
def list_profiles():
    return list(load_profiles().values())


@router.post("/")
def create_profile(profile: RedactionProfile):
    profiles = load_profiles()
    profile.id = str(uuid.uuid4())[:8]
    profiles[profile.id] = profile.model_dump()
    save_profiles(profiles)
    return profile


@router.put("/{profile_id}")
def update_profile(profile_id: str, profile: RedactionProfile):
    profiles = load_profiles()
    if profile_id not in profiles:
        raise HTTPException(404, "Profile not found")
    profile.id = profile_id
    profiles[profile_id] = profile.model_dump()
    save_profiles(profiles)
    return profile


@router.delete("/{profile_id}")
def delete_profile(profile_id: str):
    profiles = load_profiles()
    if profile_id not in profiles:
        raise HTTPException(404, "Profile not found")
    del profiles[profile_id]
    save_profiles(profiles)
    return {"deleted": profile_id}
