from dotenv import load_dotenv
load_dotenv()  # Must run before any service imports that read env vars

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from routers import upload, redact, batch, profiles, jobs
import os

app = FastAPI(title="Redacto API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # React dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Serve redacted output files
os.makedirs("./storage/outputs", exist_ok=True)
app.mount("/outputs", StaticFiles(directory="./storage/outputs"), name="outputs")

app.include_router(upload.router, prefix="/api/upload", tags=["Upload"])
app.include_router(redact.router, prefix="/api/redact", tags=["Redact"])
app.include_router(batch.router, prefix="/api/batch", tags=["Batch"])
app.include_router(profiles.router, prefix="/api/profiles", tags=["Profiles"])
app.include_router(jobs.router, prefix="/api/jobs", tags=["Jobs"])

@app.get("/api/health")
def health():
    return {"status": "ok"}
