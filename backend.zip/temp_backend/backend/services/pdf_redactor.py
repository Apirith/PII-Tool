import pymupdf  # PyMuPDF
import os
from typing import List, Dict, Any


def redact_pdf(
    input_path: str,
    output_path: str,
    pii_matches: List[Dict[str, Any]],
    redaction_style: str = "black_box",
    redact_images: bool = False,
    redact_faces: bool = False
) -> int:
    """
    Apply permanent black-box redactions to a PDF.
    Returns count of redactions applied.
    """
    doc = pymupdf.open(input_path)
    total = 0

    for page in doc:
        # --- Redact images if requested ---
        if redact_images or redact_faces:
            for img in page.get_images(full=True):
                img_name = img[7]
                bbox = page.get_image_bbox(img_name)
                if bbox:
                    label = "[IMAGE REDACTED]" if redaction_style == "label" else ""
                    page.add_redact_annot(
                        bbox,
                        text=label,
                        fill=(0, 0, 0),        # black fill
                        text_color=(1, 1, 1),   # white text
                        fontsize=9
                    )
                    total += 1

        # --- Redact PII text matches ---
        for match in pii_matches:
            original = match.get("original_text", "")
            category = match.get("category", "unknown")

            if not original or original.startswith("[IMAGE"):
                continue

            # Search for all occurrences of this text on this page
            instances = page.search_for(original, quads=False)

            for rect in instances:
                if redaction_style == "label":
                    label_map = {
                        "person_name": "[NAME]",
                        "email_address": "[EMAIL]",
                        "phone_number": "[PHONE]",
                        "location": "[ADDRESS]",
                        "date_of_birth": "[DOB]",
                        "date": "[DATE]",
                        "us_social_security_number": "[SSN]",
                        "organization": "[ORGANIZATION]",
                        "occupation": "[JOB TITLE]",
                        "medical_condition": "[MEDICAL]",
                        "credit_card_number": "[CARD NUMBER]",
                    }
                    label = label_map.get(category, f"[{category.upper().replace('_', ' ')}]")
                else:
                    label = ""  # Pure black box

                page.add_redact_annot(
                    rect,
                    text=label,
                    fill=(0, 0, 0),
                    text_color=(1, 1, 1),
                    fontsize=8
                )
                total += 1

        # Apply all redactions on this page permanently
        page.apply_redactions(images=pymupdf.PDF_REDACT_IMAGE_PIXELS)

    doc.save(output_path, garbage=4, deflate=True, clean=True)
    doc.close()
    return total
