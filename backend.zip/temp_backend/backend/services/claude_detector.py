import anthropic
import json
import os
from typing import List, Dict, Any
from models.schemas import PIIMatch, ALL_PII_CATEGORIES

DETECTION_PROMPT = """You are a precise PII and sensitive data detection engine.

Analyze the following document text and identify ALL instances of the requested
sensitive data categories. For each match, return the exact text found.

CATEGORIES TO DETECT (only flag categories that are in this list):
{categories}

DOCUMENT TEXT:
{text}

{custom_instructions}

Return a JSON array. Each element must be:
{{
  "category": "category_id_from_list",
  "original_text": "exact text as it appears in document",
  "context": "surrounding 10 words for disambiguation",
  "page_hint": "any page reference if visible in text"
}}

Rules:
- Be comprehensive. Do NOT miss any instance.
- Return ONLY the JSON array, no other text.
- If nothing is found, return an empty array [].
- For organizations: include company names, school names (high school, college,
  university), hospital names, government agencies.
- For locations: include full addresses, cities, states, ZIP codes, countries.
- Flag embedded images as category "image_all" with original_text = "[IMAGE ON PAGE X]"
"""

def detect_pii(
    text: str,
    categories: List[str],
    custom_instructions: str = ""
) -> List[Dict[str, Any]]:
    """
    Send document text to Claude for PII detection.
    Returns list of PII matches with category, original text, and context.
    """
    # Filter categories
    active_cats = [c for c in categories if c in ALL_PII_CATEGORIES
                   and c not in ("image_faces", "image_all")]  # images handled separately

    category_descriptions = {
        "person_name": "Full or partial names of people (e.g. Bob, Dr. Kay Martinez)",
        "email_address": "Email addresses",
        "phone_number": "Phone numbers, fax numbers",
        "location": "Addresses, street names, cities, ZIP codes, states, countries, coordinates",
        "date_of_birth": "Birth dates explicitly stated as such",
        "date": "Any specific calendar date",
        "us_social_security_number": "US Social Security Numbers (XXX-XX-XXXX format or similar)",
        "drivers_license": "Driver's license numbers",
        "passport_number": "Passport numbers from any country",
        "credit_card_number": "Credit card numbers",
        "credit_card_cvv": "Credit card CVV/security codes",
        "credit_card_expiration": "Credit card expiration dates",
        "banking_information": "Bank account numbers, routing numbers, IBAN",
        "account_number": "Account numbers, membership IDs, policy numbers",
        "healthcare_number": "Health insurance IDs, Medicare/Medicaid numbers",
        "medical_condition": "Diseases, syndromes, disorders, diagnoses",
        "medical_process": "Medical treatments, procedures, surgeries, tests",
        "injury": "References to bodily injuries",
        "blood_type": "Blood type references (A+, O-, AB positive, etc.)",
        "drug": "Medications, pharmaceuticals, vitamins, supplements",
        "occupation": "Job titles, professions, roles",
        "organization": "Company names, school names (high school/college/university), hospital names, organization names",
        "ip_address": "IPv4 or IPv6 addresses",
        "url": "Web URLs and internet addresses",
        "username": "Usernames, handles, login names",
        "password": "Passwords, PINs, security answers, access keys",
        "vehicle_id": "VIN numbers, license plate numbers",
        "gender_sexuality": "Gender identity or sexual orientation terms",
        "nationality": "Nationality, ethnicity, or race terms",
        "religion": "Religious affiliation or belief references",
        "political_affiliation": "Political party, movement, or ideology",
        "money_amount": "Dollar amounts, currency values, financial figures",
        "person_age": "Explicit age references (number + age context)",
        "number_sequence": "Alphanumeric ID numbers not in other categories",
        "language": "Named natural languages",
        "event": "Named events, holidays, occasions",
    }

    cats_formatted = "\n".join([
        f"- {cat}: {category_descriptions.get(cat, cat)}"
        for cat in active_cats
    ])

    extra = f"\nADDITIONAL USER INSTRUCTIONS:\n{custom_instructions}" if custom_instructions else ""

    prompt = DETECTION_PROMPT.format(
        categories=cats_formatted,
        text=text[:50000],  # Claude context limit safety
        custom_instructions=extra
    )

    client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=8000,
        messages=[{"role": "user", "content": prompt}]
    )

    try:
        raw = response.content[0].text.strip()
        # Strip markdown code fences if present
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        return json.loads(raw)
    except (json.JSONDecodeError, IndexError):
        return []
