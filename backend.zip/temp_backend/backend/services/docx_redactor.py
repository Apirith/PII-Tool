from docx import Document
from docx.shared import RGBColor
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from docx.text.paragraph import Paragraph
from typing import List, Dict, Any
from PIL import Image
import io


def _apply_black_shading(run):
    """Apply true black background shading via XML (more reliable than highlight_color)."""
    rPr = run._r.get_or_add_rPr()
    # Remove any existing shading
    for existing in rPr.findall(qn("w:shd")):
        rPr.remove(existing)
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), "000000")
    rPr.append(shd)
    run.font.color.rgb = RGBColor(0, 0, 0)


def redact_docx(
    input_path: str,
    output_path: str,
    pii_matches: List[Dict[str, Any]],
    redaction_style: str = "black_box",
    redact_images: bool = False
) -> int:
    """
    Apply redactions to a DOCX file.
    Black box = black-shaded text (same character count to minimize layout reflow).
    Label = replaces text with [CATEGORY] tag.
    Returns count of redactions applied.
    """
    doc = Document(input_path)
    total = 0

    # Build replacement map: original_text -> replacement
    replacements = {}
    for match in pii_matches:
        orig = match.get("original_text", "")
        cat = match.get("category", "unknown")
        if not orig:
            continue

        if redaction_style == "label":
            label_map = {
                "person_name": "[NAME]", "email_address": "[EMAIL]",
                "phone_number": "[PHONE]", "location": "[ADDRESS]",
                "date_of_birth": "[DOB]", "date": "[DATE]",
                "us_social_security_number": "[SSN]",
                "organization": "[ORGANIZATION]", "occupation": "[JOB TITLE]",
                "medical_condition": "[MEDICAL]", "credit_card_number": "[CARD NUMBER]",
            }
            replacements[orig] = label_map.get(cat, f"[{cat.upper().replace('_', ' ')}]")
        else:
            # Same-length block chars minimise text reflow
            replacements[orig] = "█" * len(orig)

    def redact_paragraph(para):
        nonlocal total
        full_text = para.text
        if not full_text:
            return

        for orig, replacement in replacements.items():
            if orig not in full_text:
                continue

            replaced = False

            # --- Single-run match (handles the majority of cases) ---
            for run in para.runs:
                while orig in run.text:
                    run.text = run.text.replace(orig, replacement, 1)
                    if redaction_style == "black_box":
                        _apply_black_shading(run)
                    total += 1
                    replaced = True

            # --- Cross-run match: PII text spans two or more runs ---
            if not replaced and orig in "".join(r.text for r in para.runs):
                if _redact_cross_run(para, orig, replacement, redaction_style):
                    total += 1

    doc_paragraphs = list(doc.paragraphs)

    # Process body paragraphs
    for para in doc_paragraphs:
        redact_paragraph(para)

    # Process tables
    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for para in cell.paragraphs:
                    redact_paragraph(para)

    # Process headers and footers
    for section in doc.sections:
        for para in section.header.paragraphs:
            redact_paragraph(para)
        for para in section.footer.paragraphs:
            redact_paragraph(para)

    # Process text boxes / floating shapes (not included in doc.paragraphs)
    for txbx in doc.element.body.iter(qn("w:txbxContent")):
        for p_elem in txbx.iter(qn("w:p")):
            para = Paragraph(p_elem, doc)
            redact_paragraph(para)

    # Redact all embedded images by replacing with solid black rectangles
    if redact_images:
        for rel in list(doc.part.rels.values()):
            if "image" in rel.reltype:
                img_part = rel.target_part
                try:
                    img = Image.open(io.BytesIO(img_part.blob))
                    w, h = img.size
                    black_img = Image.new("RGB", (w, h), color=(0, 0, 0))
                    out = io.BytesIO()
                    black_img.save(out, format="PNG")
                    img_part._blob = out.getvalue()
                except Exception:
                    pass

    doc.save(output_path)
    return total


def _redact_cross_run(para, orig, replacement, redaction_style):
    """
    Handle PII text that spans multiple runs.
    Merges the matched portion into the first involved run and clears the rest.
    Returns True if a match was found and replaced.
    """
    runs = para.runs
    if not runs:
        return False

    full_text = "".join(r.text for r in runs)
    start_pos = full_text.find(orig)
    if start_pos == -1:
        return False
    end_pos = start_pos + len(orig)

    # Build run boundary map
    pos = 0
    run_spans = []  # (char_start, char_end, run_index)
    for i, run in enumerate(runs):
        run_spans.append((pos, pos + len(run.text), i))
        pos += len(run.text)

    first_idx = last_idx = None
    for rs, re, i in run_spans:
        if re > start_pos and rs < end_pos:
            if first_idx is None:
                first_idx = i
            last_idx = i

    if first_idx is None:
        return False

    first_run = runs[first_idx]
    first_run_start = run_spans[first_idx][0]
    last_run_end = run_spans[last_idx][1]

    prefix = full_text[first_run_start:start_pos]
    suffix = full_text[end_pos:last_run_end]

    # Put prefix + replacement + suffix all in first run
    # (prefix/suffix keep first run's formatting; replacement gets black box)
    first_run.text = prefix + replacement + suffix
    if redaction_style == "black_box":
        _apply_black_shading(first_run)

    # Clear all other involved runs
    for i in range(first_idx + 1, last_idx + 1):
        runs[i].text = ""

    return True
