import os, re
from models.schemas import RedactionConfig
from services.claude_detector import detect_pii
from services.pdf_redactor import redact_pdf
from services.docx_redactor import redact_docx
from routers.redact import extract_text, build_replacement
import uuid

OUTPUT_DIR = os.getenv("OUTPUT_DIR", "./storage/outputs")


def process_batch_files(batch_id, file_list, cfg: RedactionConfig, status_store: dict):
    """
    Process a list of files sequentially in a background thread.
    For high-volume production use, replace with Celery tasks.
    """
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    for file_path, original_name in file_list:
        try:
            ext = file_path.rsplit(".", 1)[-1].lower()
            if ext not in ("pdf", "docx"):
                status_store[batch_id]["failed"] += 1
                continue

            job_id = str(uuid.uuid4())[:6]
            base_name = original_name.rsplit(".", 1)[0]
            safe_name = re.sub(r'[^\w\s\-]', '', base_name).strip()
            output_filename = f"{safe_name}_redacted.{ext}"
            output_path = os.path.join(OUTPUT_DIR, output_filename)

            text = extract_text(file_path, ext)
            raw_matches = detect_pii(text, cfg.categories, cfg.custom_instructions or "")

            raw_dicts = [{"category": m.get("category", ""), "original_text": m.get("original_text", "")}
                         for m in raw_matches]

            redact_images = "image_all" in cfg.categories
            if ext == "pdf":
                count = redact_pdf(file_path, output_path, raw_dicts, cfg.redaction_style, redact_images)
            else:
                count = redact_docx(file_path, output_path, raw_dicts, cfg.redaction_style, redact_images)

            status_store[batch_id]["results"].append({
                "original_filename": original_name,
                "output_filename": output_filename,
                "download_url": f"/outputs/{output_filename}",
                "total_redactions": count,
                "status": "completed"
            })
            status_store[batch_id]["completed"] += 1
            os.remove(file_path)

        except Exception as e:
            status_store[batch_id]["failed"] += 1
            status_store[batch_id]["results"].append({
                "original_filename": original_name,
                "status": "failed",
                "error": str(e)
            })

    # Mark batch as done
    completed = status_store[batch_id]["completed"]
    failed = status_store[batch_id]["failed"]
    total = status_store[batch_id]["total_files"]

    if failed == total:
        status_store[batch_id]["status"] = "failed"
    elif failed > 0:
        status_store[batch_id]["status"] = "partial"
    else:
        status_store[batch_id]["status"] = "done"
