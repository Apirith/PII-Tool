from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
import uuid, os, json, re, aiofiles
from models.schemas import RedactionConfig, RedactionResult, PIIMatch
from services.claude_detector import detect_pii
from services.pdf_redactor import redact_pdf
from services.docx_redactor import redact_docx
from dotenv import load_dotenv
from typing import List

load_dotenv()
router = APIRouter()

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "./storage/uploads")
OUTPUT_DIR = os.getenv("OUTPUT_DIR", "./storage/outputs")
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(OUTPUT_DIR, exist_ok=True)


@router.post("/single", response_model=RedactionResult)
async def redact_single(
    file: UploadFile = File(...),
    config: str = Form(...)   # JSON string of RedactionConfig
):
    """Redact a single PDF or DOCX file."""
    cfg = RedactionConfig(**json.loads(config))

    filename = file.filename or "document"
    ext = filename.rsplit(".", 1)[-1].lower()
    if ext not in ("pdf", "docx"):
        raise HTTPException(400, "Only PDF and DOCX files are supported.")

    job_id = str(uuid.uuid4())[:8]
    input_path = os.path.join(UPLOAD_DIR, f"{job_id}_input.{ext}")

    # Keep a permanent original copy so Manual Studio can re-process
    original_path = os.path.join(OUTPUT_DIR, f"{job_id}_original.{ext}")

    base_name = filename.rsplit(".", 1)[0]
    safe_name = re.sub(r'[^\w\s\-]', '', base_name).strip()
    output_filename = f"{safe_name}_redacted.{ext}"
    output_path = os.path.join(OUTPUT_DIR, output_filename)

    # Save uploaded file
    async with aiofiles.open(input_path, "wb") as f:
        await f.write(await file.read())

    # Save a permanent original copy (needed for adjust re-processing)
    import shutil
    shutil.copy2(input_path, original_path)

    # Step 1: Extract text
    text = extract_text(input_path, ext)

    # Step 2: Detect PII with Claude
    raw_matches = detect_pii(
        text=text,
        categories=cfg.categories,
        custom_instructions=cfg.custom_instructions or ""
    )

    # Step 3: Build PIIMatch objects
    pii_matches = [
        PIIMatch(
            category=m.get("category", "unknown"),
            original_text=m.get("original_text", ""),
            replacement=build_replacement(m.get("category", ""), m.get("original_text", ""), cfg.redaction_style),
            page=0
        )
        for m in raw_matches if m.get("original_text")
    ]

    # Step 4: Apply redactions
    redact_images = "image_all" in cfg.categories
    redact_faces = "image_faces" in cfg.categories
    raw_dicts = [{"category": m.category, "original_text": m.original_text} for m in pii_matches]

    if ext == "pdf":
        count = redact_pdf(input_path, output_path, raw_dicts, cfg.redaction_style, redact_images, redact_faces)
    else:
        count = redact_docx(input_path, output_path, raw_dicts, cfg.redaction_style, redact_images)

    # Save job metadata — includes original path for re-processing
    meta_path = os.path.join(OUTPUT_DIR, f"{job_id}_meta.json")
    with open(meta_path, "w") as mf:
        json.dump({
            "job_id": job_id,
            "original_filename": filename,
            "output_filename": output_filename,
            "original_path": original_path,    # ← used by adjust endpoint
            "ext": ext,                         # ← used by adjust endpoint
            "redaction_style": cfg.redaction_style,
            "pii_found": [m.model_dump() for m in pii_matches],
            "total_redactions": count
        }, mf, indent=2)

    # Cleanup temp input (original_path is kept)
    os.remove(input_path)

    return RedactionResult(
        job_id=job_id,
        original_filename=filename,
        output_filename=output_filename,
        download_url=f"/outputs/{output_filename}",
        pii_found=pii_matches,
        total_redactions=count,
        status="completed"
    )


@router.get("/map/{job_id}")
def get_redaction_map(job_id: str):
    """Return redaction metadata for Manual Studio overlay rendering."""
    meta_path = os.path.join(OUTPUT_DIR, f"{job_id}_meta.json")
    if not os.path.exists(meta_path):
        raise HTTPException(404, "Job metadata not found")
    with open(meta_path) as f:
        return json.load(f)


@router.post("/adjust/{job_id}")
def adjust_redactions(job_id: str, excluded_indices: List[int]):
    """
    Re-apply redactions with a subset of PII matches excluded.

    Body: JSON array of integer indices from pii_found that should NOT be redacted.
    Example: [0, 3, 7] — un-redacts items at those positions in pii_found.

    Returns the updated output_filename and download_url.
    """
    meta_path = os.path.join(OUTPUT_DIR, f"{job_id}_meta.json")
    if not os.path.exists(meta_path):
        raise HTTPException(404, "Job not found")

    with open(meta_path) as f:
        meta = json.load(f)

    original_path = meta.get("original_path")
    ext = meta.get("ext")
    redaction_style = meta.get("redaction_style", "black_box")
    pii_found = meta.get("pii_found", [])

    # Validate original file still exists
    if not original_path or not os.path.exists(original_path):
        raise HTTPException(
            410,
            "Original file has been cleaned up and is no longer available for re-processing. "
            "Please re-upload the document."
        )

    # Filter out excluded items
    active_matches = [
        {"category": m["category"], "original_text": m["original_text"]}
        for i, m in enumerate(pii_found)
        if i not in excluded_indices
    ]

    # Re-generate output file
    base_name = meta["original_filename"].rsplit(".", 1)[0]
    safe_name = re.sub(r'[^\w\s\-]', '', base_name).strip()
    output_filename = f"{safe_name}_redacted.{ext}"
    output_path = os.path.join(OUTPUT_DIR, output_filename)

    try:
        if ext == "pdf":
            count = redact_pdf(original_path, output_path, active_matches, redaction_style)
        else:
            count = redact_docx(original_path, output_path, active_matches, redaction_style)
    except Exception as e:
        raise HTTPException(500, f"Re-processing failed: {str(e)}")

    # Update metadata to reflect the adjustment
    meta["total_redactions"] = count
    meta["excluded_indices"] = excluded_indices
    with open(meta_path, "w") as f:
        json.dump(meta, f, indent=2)

    return {
        "job_id": job_id,
        "output_filename": output_filename,
        "download_url": f"/outputs/{output_filename}",
        "total_redactions": count,
        "excluded_count": len(excluded_indices),
        "status": "adjusted"
    }


def extract_text(path: str, ext: str) -> str:
    """Extract plain text from PDF or DOCX."""
    if ext == "pdf":
        import pymupdf
        doc = pymupdf.open(path)
        return "\n".join(page.get_text() for page in doc)
    elif ext == "docx":
        from docx import Document
        doc = Document(path)
        return "\n".join(p.text for p in doc.paragraphs)
    return ""


def build_replacement(category: str, original: str, style: str) -> str:
    label_map = {
        "person_name": "[NAME]", "email_address": "[EMAIL]",
        "phone_number": "[PHONE]", "location": "[ADDRESS]",
        "date_of_birth": "[DOB]", "organization": "[ORGANIZATION]",
        "occupation": "[JOB TITLE]", "medical_condition": "[MEDICAL]",
        "us_social_security_number": "[SSN]", "credit_card_number": "[CARD #]",
    }
    if style == "label":
        return label_map.get(category, f"[{category.upper().replace('_', ' ')}]")
    return "█" * max(len(original), 6)
